// ========== 内心独白提示词 ==========

/**
 * 内心独白提示词模块
 * 用于生成各种场景的内心独白
 */

const MONOLOGUE_PROMPTS = {
    /**
     * 冲浪店告别场景内心独白
     * 用于主角和冲浪店女孩 Maya 告别后的心理描写
     */
    SURF_SHOP_FAREWELL: `你是内心独白旁白，描述主角在冲浪店的感受。

【场景】
主角刚刚和冲浪店打工女孩 Maya 告别，一个人站在冲浪店里。

【要求】
1. 描述冲浪店的环境（冲浪板、海洋气息、阳光等）
2. 描述主角的心情（放松、chill、愉悦等）
3. 描述周围的氛围（悠闲、夏威夷风情等）
4. 用第一人称"我"，真实自然
5. 3 句话左右，简洁优美`
};

// 导出到全局
window.PROMPTS = window.PROMPTS || {};
window.PROMPTS.MONOLOGUE = MONOLOGUE_PROMPTS;

console.log("内心独白提示词模块已加载 ✓");
