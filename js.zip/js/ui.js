// ========== UI 渲染模块 ==========
// 负责所有消息显示和 UI 交互

/**
 * 消息工厂函数 - 统一创建消息元素
 * @param {string} type - 消息类型 ('player', 'npc', 'inner-monologue', 'system')
 * @param {string} sender - 发送者（可选）
 * @param {string|string[]} content - 内容（可以是字符串或数组）
 * @param {object} options - 额外选项
 * @param {string} options.senderColor - 发送者文字颜色
 * @param {string} options.contentColor - 内容文字颜色
 * @param {string} options.backgroundColor - 背景颜色
 * @param {string} options.borderColor - 边框颜色
 * @returns {HTMLDivElement} 创建的消息元素
 */
function createMessage(type, sender = null, content, options = {}) {
    const chatContainer = document.getElementById('chatContainer');
    
    const message = document.createElement('div');
    message.className = `message ${type}-message`;
    
    // 如果有 sender，添加 sender 头
    let html = '';
    if (sender) {
        const senderStyle = options.senderColor ? `style="color: ${options.senderColor};"` : '';
        html += `<div class="message-sender" ${senderStyle}>${sender}</div>`;
    }
    
    // 处理内容（支持字符串或数组）
    if (Array.isArray(content)) {
        content.forEach(item => {
            if (typeof item === 'string') {
                const contentStyle = options.contentColor ? `style="color: ${options.contentColor};"` : '';
                html += `<div ${contentStyle}>${item}</div>`;
            } else if (item.html) {
                html += item.html;
            } else if (item.text) {
                const contentStyle = options.contentColor ? `style="color: ${options.contentColor};"` : '';
                html += `<div ${contentStyle}>${item.text}</div>`;
            }
        });
    } else {
        const contentStyle = options.contentColor ? `style="color: ${options.contentColor};"` : '';
        html += `<div ${contentStyle}>${content}</div>`;
    }
    
    // 添加额外 class
    if (options.extraClass) {
        message.classList.add(options.extraClass);
    }
    
    // 添加 ID（如果需要）
    if (options.id) {
        message.id = options.id;
    }
    
    // 自定义背景色
    if (options.backgroundColor) {
        message.style.background = options.backgroundColor;
    }
    
    // 自定义边框颜色
    if (options.borderColor) {
        message.style.borderColor = options.borderColor;
    }
    
    message.innerHTML = html;
    chatContainer.appendChild(message);
    scrollToBottom();
    
    return message;
}

/**
 * 滚动聊天容器到底部
 */
function scrollToBottom() {
    const chatContainer = document.getElementById('chatContainer');
    chatContainer.scrollTop = chatContainer.scrollHeight;
}

/**
 * 清空聊天容器
 */
function clearChat() {
    const chatContainer = document.getElementById('chatContainer');
    chatContainer.innerHTML = '';
}

/**
 * 显示场景旁白
 * @param {string} type - 旁白类型（如"到达 威基基海滩"、"Day 1 结束"）
 * @param {string} content - 旁白内容
 */
function showSceneNarration(type, content) {
    const chatContainer = document.getElementById('chatContainer');
    
    // 根据类型自动匹配 emoji
    const emojiMap = {
        '到达': '📍',
        'Day': type.includes('结束') ? '🌅' : '🌞',
        '晚宴': '🌺',
        '环境': '🌴'
    };
    
    let emoji = '📝'; // 默认
    for (const [key, value] of Object.entries(emojiMap)) {
        if (type.includes(key)) {
            emoji = value;
            break;
        }
    }
    
    const narrationElement = document.createElement('div');
    narrationElement.className = 'message inner-monologue';
    narrationElement.innerHTML = `
        <div class="message-sender" style="font-size: 0.8em; color: #999;">
            ${emoji} ${type}
        </div>
        <div style="font-style: italic; font-size: 0.9em; color: #666;">
            ${content.replace(/\n/g, '<br>')}
        </div>
    `;
    chatContainer.appendChild(narrationElement);
    scrollToBottom();
}

/**
 * 生成并显示内心独白
 * @param {string} context - 情境描述
 * @param {string} emotionHint - 情感提示
 */
async function generateInnerMonologue(context, emotionHint) {
    try {
        const monologuePrompt = `基于以下情境，生成一段主角的内心独白。主角是 20 岁的中国女大学生，第一次来夏威夷独自旅行。${emotionHint ? `可以包含${emotionHint}等情感。` : ''}请用中文，简洁生动：\n\n${context}`;
        
        const response = await fetch(CONFIG.apiUrl, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${CONFIG.apiKey}`
            },
            body: JSON.stringify({
                model: "deepseek-chat",
                messages: [
                    {
                        role: "system",
                        content: "你是一个内心独白的专家，善于表达人物的真实情感。请用中文，第一人称，简洁生动，不要太长。"
                    },
                    {
                        role: "user",
                        content: monologuePrompt
                    }
                ],
                max_tokens: 80,
                temperature: 0.9
            })
        });
        
        if (!response.ok) {
            throw new Error(`API 请求失败`);
        }
        
        const data = await response.json();
        const monologue = data.choices[0].message.content.trim();
        
        const monologueElement = document.createElement('div');
        monologueElement.className = 'message inner-monologue';
        monologueElement.innerHTML = `
            <div class="message-sender" style="font-size: 0.8em; color: #999;">💭 内心独白</div>
            <div style="font-style: italic; font-size: 0.9em; color: #666;">${monologue}</div>
        `;
        document.getElementById('chatContainer').appendChild(monologueElement);
        scrollToBottom();
        
        return monologue;
    } catch (error) {
        console.error("内心独白生成失败:", error);
        return null;
    }
}

/**
 * 显示玩家消息
 * @param {string} text - 消息内容
 */
function displayPlayerMessage(text) {
    return createMessage('player', '你', text);
}

/**
 * 显示 NPC 消息
 * @param {string} npcName - NPC 名称
 * @param {string} text - 英文原文
 * @param {string} translation - 中文翻译
 */
function displayNPCMessage(npcName, text, translation) {
    // 清理中文动作词（防御性处理）
    const cleanedText = window.cleanNpcDialogue ? window.cleanNpcDialogue(text) : text;
    const cleanedTranslation = window.cleanNpcDialogue ? window.cleanNpcDialogue(translation) : translation;
    
    return createMessage('npc', `${getNpcEmoji(npcName)} ${npcName}`, [
        cleanedText,
        { html: `<div class="translation">${cleanedTranslation}</div>` }
    ]);
}

/**
 * 显示加载提示
 * @param {string} npcName - NPC 名称
 */
function displayLoadingMessage(npcName) {
    const chatContainer = document.getElementById('chatContainer');
    
    const loadingMessage = document.createElement('div');
    loadingMessage.className = 'message npc-message';
    loadingMessage.id = 'loadingMessage';
    
    // 获取 NPC emoji（添加错误处理）
    let npcEmoji = "🤖";
    try {
        if (typeof getNpcEmoji === 'function') {
            npcEmoji = getNpcEmoji(npcName);
        }
    } catch (e) {
        console.warn("获取 NPC emoji 失败:", e);
    }
    
    loadingMessage.innerHTML = `
        <div class="message-sender">${npcEmoji} ${npcName}</div>
        <div>正在思考...</div>
    `;
    chatContainer.appendChild(loadingMessage);
    scrollToBottom();
    
    return loadingMessage;
}

/**
 * 移除加载提示
 */
function removeLoadingMessage() {
    const loadingMessage = document.getElementById('loadingMessage');
    if (loadingMessage) {
        loadingMessage.remove();
    }
}

/*

/**
 * 显示选项让玩家选择
 * @param {Array} options - 选项数组，每个选项包含：
 *   - text: string - 选项文本（可包含 emoji）
 *   - gradient: string - 渐变背景色（可选，默认紫色渐变）
 *   - boxShadow: string - 阴影颜色（可选）
 *   - onClick: function - 点击回调函数
 * @returns {HTMLElement} 选项容器元素
 */
function showOptions(options) {
    const chatContainer = document.getElementById('chatContainer');
    
    // 创建选项容器
    const optionsContainer = document.createElement('div');
    optionsContainer.className = 'options-container';
    optionsContainer.style.cssText = `
        display: flex;
        flex-direction: column;
        gap: 10px;
        margin: 20px 0;
        padding: 15px;
        background: rgba(255,255,255,0.5);
        border-radius: 15px;
        border: 2px solid #bde0fe;
    `;
    
    // 创建每个选项按钮
    options.forEach(option => {
        const optionButton = document.createElement('div');
        optionButton.className = 'option-button';
        
        // 使用传入的渐变色或默认紫色渐变
        const gradient = option.gradient || 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)';
        
        // 计算阴影颜色（从渐变色或单独指定）
        let boxShadow = option.boxShadow;
        if (!boxShadow) {
            // 根据渐变色类型设置默认阴影
            if (gradient.includes('#667eea')) {
                boxShadow = '0 3px 8px rgba(102, 126, 234, 0.3)';
            } else if (gradient.includes('#f093fb')) {
                boxShadow = '0 3px 8px rgba(240, 147, 251, 0.3)';
            } else {
                boxShadow = '0 3px 8px rgba(0,0,0,0.2)';
            }
        }
        
        // 计算悬停阴影
        let hoverBoxShadow = option.hoverBoxShadow;
        if (!hoverBoxShadow) {
            if (gradient.includes('#667eea')) {
                hoverBoxShadow = '0 5px 15px rgba(102, 126, 234, 0.4)';
            } else if (gradient.includes('#f093fb')) {
                hoverBoxShadow = '0 5px 15px rgba(240, 147, 251, 0.4)';
            } else {
                hoverBoxShadow = '0 5px 15px rgba(0,0,0,0.3)';
            }
        }
        
        optionButton.style.cssText = `
            padding: 12px 20px;
            background: ${gradient};
            color: white;
            border-radius: 10px;
            cursor: pointer;
            text-align: center;
            font-weight: bold;
            transition: all 0.3s ease;
            box-shadow: ${boxShadow};
        `;
        optionButton.innerHTML = option.text;
        
        // 悬停效果
        optionButton.onmouseover = () => {
            optionButton.style.transform = 'translateY(-2px)';
            optionButton.style.boxShadow = hoverBoxShadow;
        };
        
        optionButton.onmouseout = () => {
            optionButton.style.transform = 'translateY(0)';
            optionButton.style.boxShadow = boxShadow;
        };
        
        // 点击处理
        optionButton.onclick = async () => {
            optionsContainer.style.display = 'none';
            if (option.onClick) {
                await option.onClick();
            }
        };
        
        optionsContainer.appendChild(optionButton);
    });
    
    chatContainer.appendChild(optionsContainer);
    scrollToBottom();
    
    console.log("选项已显示，等待玩家选择...");
    
    return optionsContainer;
}

/**
 * 隐藏选项容器
 * @param {HTMLElement} optionsContainer - 选项容器元素
 */
function hideOptions(optionsContainer) {
    if (optionsContainer) {
        optionsContainer.style.display = 'none';
    }
}

/**
 * 显示撒花特效
 */
function showConfetti() {
    const colors = ['#ffc8dd', '#bde0fe', '#ffafcc', '#a8e6cf', '#dcedc1', '#ffd700'];
    const emojis = ['🌺', '', '✨', '', '🌸', '💫'];
    
    for (let i = 0; i < 50; i++) {
        setTimeout(() => {
            const confetti = document.createElement('div');
            confetti.className = 'confetti';
            
            confetti.style.left = Math.random() * 100 + 'vw';
            confetti.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
            
            const size = Math.random() * 10 + 8;
            confetti.style.width = size + 'px';
            confetti.style.height = size + 'px';
            
            const duration = Math.random() * 2 + 2;
            confetti.style.animationDuration = duration + 's';
            
            if (Math.random() < 0.3) {
                confetti.textContent = emojis[Math.floor(Math.random() * emojis.length)];
                confetti.style.backgroundColor = 'transparent';
                confetti.style.fontSize = size + 'px';
                confetti.style.textAlign = 'center';
                confetti.style.lineHeight = size + 'px';
            }
            
            document.body.appendChild(confetti);
            
            setTimeout(() => {
                confetti.remove();
            }, duration * 1000);
        }, i * 50);
    }
}

/**
 * 按钮波纹效果
 */
function initRippleEffect() {
    const buttons = document.querySelectorAll('button');
    buttons.forEach(button => {
        button.addEventListener('click', function(e) {
            if (getComputedStyle(this).position !== 'relative') {
                return;
            }
            
            const rect = this.getBoundingClientRect();
            const ripple = document.createElement('span');
            ripple.className = 'ripple';
            
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            const size = Math.max(rect.width, rect.height);
            ripple.style.width = ripple.style.height = size + 'px';
            ripple.style.left = (x - size / 2) + 'px';
            ripple.style.top = (y - size / 2) + 'px';
            
            this.appendChild(ripple);
            
            setTimeout(() => {
                ripple.remove();
            }, 600);
        });
    });
}





/**
 * 显示 Toast 提示消息
 * @param {string} message - 消息内容
 * @param {string} icon - 图标 emoji
 */
function showToast(message, icon = 'ℹ️') {
    // 移除已存在的 toast
    const existingToast = document.querySelector('.toast-notification');
    if (existingToast) {
        existingToast.remove();
    }
    
    const toast = document.createElement('div');
    toast.className = 'toast-notification';
    toast.innerHTML = `
        <span class="toast-notification-icon">${icon}</span>
        <div class="toast-notification-content">
            <div class="toast-notification-message">${message}</div>
        </div>
    `;
    
    document.body.appendChild(toast);
    
    // 3 秒后自动消失
    setTimeout(() => {
        toast.classList.add('hide');
        setTimeout(() => toast.remove(), 1500);
    }, 3000);
}

// 暴露到全局作用域
window.showConfetti = showConfetti;
window.showOptions = showOptions;
window.hideOptions = hideOptions;
window.initRippleEffect = initRippleEffect;
window.showToast = showToast;

console.log("UI 渲染模块已加载 ✓");

// 页面加载完成后自动初始化波纹效果
document.addEventListener('DOMContentLoaded', function() {
    initRippleEffect();
    console.log("波纹效果已初始化 ✓");
});
