/**
 * 生成冲浪店心理描写
 */
async function generateSurfShopInnerMonologue() {
    const chatContainer = document.getElementById('chatContainer');
    
    // 使用 prompts 模块中的冲浪店场景 prompt
    const monologuePrompt = window.PROMPTS.MONOLOGUE.SURF_SHOP_FAREWELL;
    
    let monologueText;
    try {
        monologueText = await window.callAI(
            monologuePrompt,
            "你是一个内心独白旁白，善于用优美的中文描述主角的内心感受。",
            150,
            0.8
        );
        
        // 如果 AI 返回空内容，使用备用文本
        if (!monologueText || monologueText.length < 10) {
            monologueText = "冲浪店里弥漫着海盐和阳光的味道，五颜六色的冲浪板靠在墙边。这一刻感觉好放松，整个人都 chill 下来了。夏威夷的节奏，真的很不一样。";
        }
    } catch (error) {
        console.error("生成内心独白失败:", error);
        monologueText = "冲浪店里弥漫着海盐和阳光的味道，五颜六色的冲浪板靠在墙边。这一刻感觉好放松，整个人都 chill 下来了。夏威夷的节奏，真的很不一样。";
    }
    
    // 显示内心独白
    const monologueMessage = document.createElement('div');
    monologueMessage.className = 'system-message';
    monologueMessage.style.cssText = `
        background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        color: white;
        padding: 15px;
        border-radius: 15px;
        margin: 15px 0;
        font-style: italic;
        font-size: 0.95em;
        line-height: 1.6;
    `;
    monologueMessage.innerHTML = `
        <div style="font-size: 0.85em; opacity: 0.9; margin-bottom: 8px;">💭 内心独白</div>
        ${monologueText}
    `;
    chatContainer.appendChild(monologueMessage);
    chatContainer.scrollTop = chatContainer.scrollHeight;
    
    console.log("冲浪店内心独白已生成");
}

console.log("内心独白模块已加载 ✓");

// 暴露到全局作用域
window.generateSurfShopInnerMonologue = generateSurfShopInnerMonologue;