// ========================================
// 🎮 游戏配置中心 - 消除魔法数字
// ========================================
// 所有游戏参数、概率、时间延迟都集中在这里配置
// 修改游戏行为只需要改这个文件！

const GAME_CONFIG = {
    // ============= 对话系统配置 =============
    dialogue: {
        // 对话轮数限制
        CUSTOMS_MIN_TURNS: 0,           // 海关最少对话轮数
        CUSTOMS_MAX_TURNS: 6,           // 海关最多对话轮数
        ENCOUNTER_MIN_TURNS: 1,         // 邂逅最少对话轮数
        ENCOUNTER_MAX_TURNS: 6,         // 邂逅最多对话轮数
        MEDAL_MIN_TURNS: 1,             // 成就最少对话轮数
        MEDAL_MAX_TURNS: 6,             // 成就最多对话轮数
        GUIDE_MIN_TURNS: 3,             // 导游最少对话轮数
        GUIDE_MAX_TURNS: 6,             // 导游最多对话轮数
        HOTEL_MIN_TURNS: 2,             // 酒店最少对话轮数
        HOTEL_MAX_TURNS: 6,             // 酒店最多对话轮数
        LOCATION_MIN_TURNS: 4,          // 景点最少对话轮数
        LOCATION_MAX_TURNS: 6,          // 景点最多对话轮数
        DATE_MIN_TURNS: 3,              // 约会最少对话轮数
        DATE_MAX_TURNS: 5,              // 约会最多对话轮数
        
        // 对话结束检测
        REQUIRE_FAREWELL: {
            CUSTOMS: false,             // 海关不需要告别词
            ENCOUNTER: true,            // 邂逅需要告别词
            MEDAL: true,                // 成就需要告别词
            GUIDE: false,               // 导游不需要告别词
            HOTEL: false,               // 酒店不需要告别词
            LOCATION: false             // 景点不需要告别词
        },
        
        // 文化提示生成
        CULTURE_TIP_PROBABILITY: 0.9,   // 生成文化提示的概率 (90%)
        CULTURE_TIP_PROBABILITY_LOW: 0.8 // 低概率生成文化提示 (80%)
    },
    
    // ============= 概率配置 =============
    probability: {
        // 随机事件概率
        ENCOUNTER_CHANCE: 0.5,          // 邂逅概率 (50%)
        MEDAL_CHANCE: 0.5,              // 成就概率 (50%)
        
        // 地点相关概率
        SURF_SHOP_MEDAL_CHANCE: 0.7,    // 冲浪店成就概率 (70%)
        LOCATION_ENCOUNTER_CHANCE: 0.6, // 地点邂逅概率 (60%)
        LOCATION_MEDAL_CHANCE: 0.6,     // 地点成就概率 (60%)
        
        // 其他概率
        CONFETTI_EMOJI_CHANCE: 0.3,     // 撒花中使用 emoji 的概率 (30%)
        DATE_END_CHANCE: 0.5            // 约会结束概率 (50%)
    },
    
    // ============= 时间延迟配置 (毫秒) =============
    timing: {
        // 加载动画延迟
        LOADING_DOTS_INTERVAL: 400,     // 省略号动画间隔 (400ms)
        LOADING_DOTS_MAX: 6,            // 省略号最大数量
        AIRPORT_EVENT_DELAY: 100,       // 机场事件延迟 (100ms)
        TRANSITION_LOADING_DELAY: 1000, // 转场加载延迟 (1 秒)
        
        // Toast 通知
        TOAST_AUTO_HIDE_DELAY: 2000,    // Toast 自动隐藏延迟 (2 秒)
        TOAST_FADE_OUT_DURATION: 1500,  // Toast 淡出动画时长 (1.5 秒)
        TOAST_SHOW_DELAY: 100,          // Toast 显示延迟 (100ms)
        
        // 邀约系统
        INVITATION_SMS_DELAY: 2000,     // 邀约短信延迟 (2 秒)
        INVITATION_AUTO_HIDE_DELAY: 2000, // 邀约自动隐藏延迟 (2 秒)
        
        // 场景转换
        SCENE_NARRATION_DELAY: 300,     // 场景旁白显示延迟 (300ms)
        NPC_DIALOGUE_DELAY: 50,         // NPC 对话生成延迟 (50ms)
        ITINERARY_GENERATE_DELAY: 500,  // 行程生成延迟 (500ms)
        INNER_MONOLOGUE_DELAY: 500,     // 内心独白延迟 (500ms)
        
        // 动画时长
        FADE_OUT_DURATION: 300,         // 淡出动画时长 (300ms)
        MODAL_SHOW_DELAY: 10,           // 模态框显示延迟 (10ms)
        CONFETTI_DURATION: 3000,        // 撒花持续时间 (3 秒)
        CONFETTI_INTERVAL: 50,          // 撒花生成间隔 (50ms)
        
        // 测试工具
        TEST_DELAY: 100                 // 测试工具延迟 (100ms)
    },
    
    // ============= AI 模型配置 =============
    ai: {
        // 模型参数
        DEFAULT_TEMPERATURE: 0.7,       // 默认温度 (创造性)
        DIALOGUE_TEMPERATURE: 0.8,      // 对话温度 (更自然)
        JSON_TEMPERATURE: 0.9,          // JSON 生成温度 (更结构化)
        TRANSLATION_TEMPERATURE: 0.3,   // 翻译温度 (更准确)
        MONOLOGUE_TEMPERATURE: 0.9,     // 内心独白温度 (更生动)
        
        // Token 限制
        DEFAULT_MAX_TOKENS: 800,        // 默认最大 token 数
        DIALOGUE_MAX_TOKENS: 800,       // 对话最大 token 数
        JSON_MAX_TOKENS: 400,           // JSON 最大 token 数
        TRANSLATION_MAX_TOKENS: 300,    // 翻译最大 token 数
        MONOLOGUE_MAX_TOKENS: 80,       // 内心独白最大 token 数
        NARRATION_MAX_TOKENS: 300,      // 旁白最大 token 数
        
        // API 配置
        API_URL: "https://api.deepseek.com/v1/chat/completions",
        API_KEY: "sk-a0e31c0e743847eea76c53ba20fa985f", // ⚠️ 建议移到环境变量
        MODEL_NAME: "deepseek-chat"
    },
    
    // ============= 游戏进度配置 =============
    progress: {
        // 地点配置
        TOTAL_PRIMARY_LOCATIONS: 5,     // 主要地点总数 (用于进度条)
        DEFAULT_LOCATIONS_COUNT: 4,     // 默认行程地点数
        
        // 行程配置
        ITINERARY_DAYS: 4,              // 行程天数
        SECONDARY_LOCATIONS_PER_PRIMARY: 3, // 每个一级地点的二级地点数
        
        // 酒店配置
        HOTEL_CHECKIN_DIALOGUE_TURNS: 2, // 酒店入住对话轮数触发卢奥晚宴
        
        // 进度计算
        PROGRESS_LABELS: {
            0: "刚刚开始",
            20: "探索中...",
            40: "渐入佳境",
            60: "半途而废？不存在的！",
            80: "接近尾声",
            100: "即将完成！"
        }
    },
    
    // ============= UI 配置 =============
    ui: {
        // 按钮配置
        RIPPLE_DURATION: 600,           // 波纹动画时长 (600ms)
        BUTTON_HOVER_SCALE: 1.02,       // 按钮悬停缩放
        
        // 消息配置
        MESSAGE_MAX_WIDTH: 80,          // 消息最大宽度 (%)
        SYSTEM_MESSAGE_MAX_WIDTH: 90,   // 系统消息最大宽度 (%)
        
        // 面板配置
        MODAL_MAX_WIDTH: 600,           // 模态框最大宽度 (px)
        MODAL_MAX_HEIGHT: 70,           // 模态框最大高度 (vh)
        HOME_PANEL_MAX_WIDTH: 500,      // 主页面板最大宽度 (px)
        
        // 字体大小
        SCENE_NAME_FONT_SIZE: 1.2,      // 场景名称字体大小 (em)
        FUNCTION_BTN_ICON_FONT_SIZE: 2.5, // 功能按钮图标字体大小 (em)
        
        // 动画
        MOUSE_EMOJI_FONT_SIZE: 20,      // 鼠标跟随 emoji 字体大小 (px)
        MOUSE_EMOJI_DURATION: 2000      // 鼠标跟随 emoji 动画时长 (ms)
    },
    
    // ============= NPC 配置 =============
    npc: {
        // 默认 NPC 属性
        DEFAULT_AGE: 25,                // 默认 NPC 年龄
        DEFAULT_RELATIONSHIP_LEVEL: 1,  // 默认关系等级
        
        // 固定 NPC
        LANI_AGE: 22,                   // 导游 Lani 年龄
        LANI_OCCUPATION: "Tour Guide",  // 导游 Lani 职业
        
        // 关系系统
        RELATIONSHIP_LEVELS: {
            1: "陌生人",
            2: "认识",
            3: "朋友",
            4: "好友",
            5: "亲密"
        }
    },
    
    // ============= 成就系统配置 =============
    medal: {
        TOTAL_MEDALS: 10,               // 总成就数 (预留)
        MEDAL_DISPLAY_PER_PAGE: 5       // 每页显示成就数
    },
    
    // ============= 存档配置 =============
    save: {
        AUTO_SAVE_INTERVAL: 30000,      // 自动保存间隔 (30 秒)
        SAVE_KEY_PREFIX: "hawaii_save_" // 存档键名前缀
    },
    
    // ============= 调试配置 =============
    debug: {
        ENABLE_TEST_MENU: true,         // 启用测试菜单
        ENABLE_DEBUG_LOGS: true,        // 启用调试日志
        TEST_MODE_FORCE_EVENT: false,   // 测试模式：强制触发事件
        FORCE_ENCOUNTER_CHANCE: 1.0,    // 测试模式：邂逅概率 100%
        FORCE_MEDAL_CHANCE: 1.0         // 测试模式：成就概率 100%
    }
};

// ============= 向后兼容：暴露到全局 =============
window.GAME_CONFIG = GAME_CONFIG;

// ============= 工具函数 =============

/**
 * 获取配置值（支持嵌套路径）
 * @param {string} path - 配置路径，如 "dialogue.CUSTOMS_MAX_TURNS"
 * @param {*} defaultValue - 默认值
 * @returns {*} 配置值
 */
function getConfig(path, defaultValue) {
    const keys = path.split('.');
    let value = GAME_CONFIG;
    
    for (const key of keys) {
        if (value && value[key] !== undefined) {
            value = value[key];
        } else {
            return defaultValue;
        }
    }
    
    return value;
}

/**
 * 更新配置值（运行时）
 * @param {string} path - 配置路径
 * @param {*} value - 新值
 */
function setConfig(path, value) {
    const keys = path.split('.');
    let obj = GAME_CONFIG;
    
    for (let i = 0; i < keys.length - 1; i++) {
        if (!obj[keys[i]]) {
            obj[keys[i]] = {};
        }
        obj = obj[keys[i]];
    }
    
    obj[keys[keys.length - 1]] = value;
}

// 暴露工具函数到全局
window.getConfig = getConfig;
window.setConfig = setConfig;

console.log("✅ 游戏配置中心已加载 - 所有魔法数字已集中管理！");
console.log("💡 使用 getConfig('dialogue.ENCOUNTER_MAX_TURNS') 获取配置值");
